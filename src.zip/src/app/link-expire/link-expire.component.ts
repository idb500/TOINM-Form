import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-link-expire',
  templateUrl: './link-expire.component.html',
  styleUrls: ['./link-expire.component.scss']
})
export class LinkExpireComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
