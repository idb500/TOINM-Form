import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-documentexists',
  templateUrl: './documentexists.component.html',
  styleUrls: ['./documentexists.component.scss']
})
export class DocumentexistsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
