import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toi-form',
  templateUrl: './toi-form.component.html',
  styleUrls: ['./toi-form.component.scss']
})
export class ToiFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
